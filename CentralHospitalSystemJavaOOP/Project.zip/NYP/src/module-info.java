/**
 * 
 */
/**
 * 
 */
module NYP {
	requires java.desktop;
	requires org.junit.jupiter.api;
	requires junit;
	requires org.junit.platform.suite.api;
	
}